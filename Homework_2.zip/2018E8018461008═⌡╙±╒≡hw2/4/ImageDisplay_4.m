figure;
subplot(3,2,1)%չʾԭͼ
load('Image4.mat');
image(test4);
colormap(gray(256));
axis image;
axis off
title('Original blurred image');
%================================
I=test4; % ���þ�ֵ�˲���
A=[0 1 0;
    1 -4 1;
    0 1 0];
I1=conv2(I,A,'same');
subplot(3,2,3);
imshow(I1);title('filtering 1');
%================================
I=test4; % ���þ�ֵ�˲���
A=[1 1 1;
    1 -8 1;
    1 1 1];
I1=conv2(I,A,'same');
subplot(3,2,4);
imshow(I1);title('filtering 2');
%================================
I=test4; % ���þ�ֵ�˲���
A=[0 -1 0;
    -1 4 -1;
   0 -1 0];
I1=conv2(I,A,'same');
subplot(3,2,5);
imshow(I1);title('filtering 3');
%================================
I=test4; % ���þ�ֵ�˲���
A=[-1 -1 -1;
    -1 8 -1;
    -1 -1 -1];
I1=conv2(I,A,'same');
subplot(3,2,6);
imshow(I1);title('filtering 4');