function dst_img=myBitEnhance(src_img,fa,ga,gb)    
  
[height,width] = size(src_img);  
dst_img=uint8(zeros(height,width));  
  
src_img=double(src_img);  
  
%����б��    
for i=1:height  
    for j=1:width %�����ζ�ӦԪ��һһ�任 
            if src_img(i,j) <= fa  
                dst_img(i,j)= 0;  
            else  
                dst_img(i,j)=255;  
            end  
    end  
end  
dst_img=uint8(dst_img); 