% this is a sample code to display an image in gray level;
fa=96; fb=160; %����   
ga=32; gb=216; %���� 
pixel_f=1:256; %�任����ʾ��ͼ��ʼ��
pixel_g=zeros(1,256); 
k1=double(ga/fa); %�任��������б��   
k2=(gb- ga)/(fb- fa);  
k3=(256- gb)/(256- fb);  
for i=1:256  
    if i <= fa  
        pixel_g(i)= k1*i;  
    elseif fa < i && i <= fb  
        pixel_g(i)= k2*( i- fa)+ ga;  
    else  
        pixel_g(i)= k3*( i - fb)+ gb;  
    end  
end  
subplot(2,2,1) 
plot(pixel_f,pixel_g); 
title('�任����');
grid on
%=================================================
subplot(2,2,2)%չʾԭͼ
load('Image1.mat');
image(test1);
colormap(gray(256));
axis image;
axis off
title('ԭʼͼ��');
%================================
I=test1;
J=myLinearEnhance(I,fa,fb,ga,gb);  
subplot(2,2,3);
imshow(J);title(' ��������ͼ��');
%==========================
I=test1;
J=myBitEnhance(I,120);  
subplot(2,2,4);
imshow(J);title('r1 = r2 = 120,s1 = 0, s2 = 255'); 
