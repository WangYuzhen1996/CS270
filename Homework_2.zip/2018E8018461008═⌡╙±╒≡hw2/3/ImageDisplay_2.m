figure;
subplot(2,2,1)%չʾԭͼ
load('Image3.mat');
image(test3);
colormap(gray(256));
axis image;
axis off
title('Original blurred image');
%================================
I=test3; % ���þ�ֵ�˲���
A=1/9*[1 1 1;
    1 1 1;
    1 1 1];
I1=conv2(I,A,'same');
subplot(2,2,2);
imshow(I1);title('Average filtering 1');
%========================= 
A=1/16*[1 2 1;% ���þ�ֵ�˲���
    2 4 2;
    1 2 1];
I2=conv2(I,A,'same');
subplot(2,2,3);
imshow(I2);title('Average filtering 2');
%=========================
I3 = medfilt_my(I); % ������ֵ�˲���
subplot(2,2,4);
imshow(I3);title('median filtering');

