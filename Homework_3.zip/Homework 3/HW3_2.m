% ������
clc
clear
load('Test2.mat');
%===================
%ԭͼ
subplot(3,2,1);
image(f);
colormap(gray(256));axis image;axis off;title('Original image');
%=====================
I=f; % spatial Laplacian operator
A=[-1 -1 -1;
    -1 8 -1;
    -1 -1 -1];
I1=conv2(I,A,'same');
subplot(3,2,3);
image(4*I1+I);
colormap(gray(256));axis image;axis off;title('spatial Laplacian operator');
%=================================================
D0 = 50;
%===========================================
%�����ͨ�˲���IHPF
PQ = paddedsize(size(I));
H = hpfilter('ideal', PQ(1), PQ(2), D0);
gbw = dftfilt(f, H);
subplot(3,2,4);
image(0.7*gbw+I);
colormap(gray(256));axis image;axis off;title('c=0.7�����ͨ�˲���IHPF');
%===========================================================================
%������˹��ͨ�˲���BHPF
PQ = paddedsize(size(I));
%D0 = 0.05*PQ(1);
H = hpfilter('btw', PQ(1), PQ(2), D0,2);
gbw = dftfilt(f, H);
subplot(3,2,5);
image(3*gbw+I);
colormap(gray(256));axis image;axis off;title('c=3������˹��ͨ�˲���BHPF');
%=====================================================================
%��˹��ͨ�˲���GHPF
PQ = paddedsize(size(I));
%D0 = 0.05*PQ(1);
H = hpfilter('gaussian', PQ(1), PQ(2), D0);
gbw = dftfilt(f, H);
subplot(3,2,6);
image(4*gbw+I);
colormap(gray(256));axis image;axis off;title('c=3��˹��ͨ�˲���GHPF');



