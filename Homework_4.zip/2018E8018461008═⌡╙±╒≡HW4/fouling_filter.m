function img_fouling = fouling_filter(img,a,b,T)% +45 ����������
[M,N] = size(img);
F = fft2(img);
for u = 1:M
    for v = 1:N
        K(u,v) = pi * (u * a + v * b);
        H(u,v) = T * sin(K(u,v)) * exp(-1j * K(u,v))/K(u,v);
        G(u,v) = H(u,v) * F(u,v);
    end
end
img_fouling = ifft2(G);
img_fouling = uint8(abs(img_fouling));
end