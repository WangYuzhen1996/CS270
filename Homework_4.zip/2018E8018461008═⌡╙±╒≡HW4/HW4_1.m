figure;
load('Test1.mat');
%============================================================
G=noise_my( 'gaussian', 1024, 1024, 50, 25);
I=f; 
I1=uint8(G)+I;
subplot(2,2,1);
colormap(gray(256));
image(I1);
axis image;axis off;title('image with gaussian noise');
%============================================================
g_hist = imhist(I1);        % ���ֱ��ͼ
subplot(2,2,2);bar(0:255,g_hist,'b');title('imhist����ֱ��ͼ');
%=============================================================
S=noise_my( 'salt & pepper', 1024, 1024, 0.1, 0.1);
I2=f; 
c=find(S==0);
I2(c)=0; 
c=find(S==255);
I2(c)=255; 
colormap(gray(256));subplot(2,2,3);image(I2);
axis image;axis off;colormap(gray(256));title('image with salt&peper');
%=========================
g_hist = imhist(I2);        % ���ֱ��ͼ
subplot(2,2,4);bar(0:255,g_hist,'b');title('imhist����ֱ��ͼ');
