function img_wiener = wiener_filter(img_src,img_degradation,K) % ά���˲�
[M,N] = size(img_src);
S = fft2(img_src);
G = fft2(img_degradation);
for u = 1:M
    for v = 1:N
        H(u,v) = G(u,v)/S(u,v);
        F(u,v) = 1/H(u,v)*(abs(H(u,v)))^2/((abs(H(u,v)))^2+K)*G(u,v);
    end
end
img_wiener = ifft2((F));
img_wiener = uint8(abs(img_wiener));
end