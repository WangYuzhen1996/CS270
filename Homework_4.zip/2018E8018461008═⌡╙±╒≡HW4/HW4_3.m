close all;
clear all;
figure(1);
subplot(1,2,1)
%==========================================================================
%չʾԭͼ
load('Test3.mat'); 
I1 = f; 
colormap(gray(256)); image(I1);
axis image; axis off; colormap(gray(256)); title('original image');
%===============================================================================
%�������Ҳ�����
[m,n]=size(I1);
u0=m/2; v0=0;A=70;
for x=1:m
    for y=1:n
        f(x,y)=A*cos(u0*x+v0*y);
    end
end
I2 = I1+ f; %�������Ҳ����� %subplot(2,2,2);
subplot(1,2,2)
image(I2);colormap(gray(256));axis image;axis off;title('image with cos noise');
%=========================================================================
I_frequency=fftshift(fft2(I2,2*m,2*n)); %subplot(2,2,3);
figure(2);
imshow(uint8(I_frequency));axis image;axis off;colormap(gray(256));title('image_frequency');
%==========================================================================
%�ݲ��˲���
k=3;
D0k=30;
P=m*2;
Q=n*2;
H=ones(P,Q);
for x = (-P/2):(P/2)-1
    for y = (-Q/2):(Q/2)-1
      Dk = sqrt((x+u0)^2+(y+v0)^2); % �˲����ľ������
      H(x+(P/2)+1,y+(Q/2)+1) = H(x+(P/2)+1,y+(Q/2)+1) * 1/(1+(D0k/Dk)^8);
      Dk = sqrt((x-u0)^2+(y-v0)^2); % �˲����ľ������
      H(x+(P/2)+1,y+(Q/2)+1) = H(x+(P/2)+1,y+(Q/2)+1) * 1/(1+(D0k/Dk)^8);
    end
end
I3=H .* I_frequency;
I4=real(ifft2(ifftshift(I3)));
I5=I4(1:m,1:n);
figure(3);
image(uint8(I5)); colormap(gray(256)); axis image; axis off; title('Notch-filter');
%=================================================================================