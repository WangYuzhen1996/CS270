close all;
clear all;
test3=importdata('Test3.mat');
figure(1);
imshow(uint8(test3));
[m,n]=size(test3);
u0=m/2;
v0=0;
A=70;
%�������Ҳ�����
for x=1:m
    for y=1:n
        f(x,y)=A*cos(u0*x+v0*y);
    end
end
g=double(test3)+f;
figure(2);
imshow(uint8(g));
g_f=fftshift(fft2(g,2*m,2*n));
figure(3);
imshow(uint8(g_f));
k=3;
D0k=30;
%����ݲ��˲���
P=m*2;
Q=n*2;
H=ones(P,Q);
for x=(-P/2):(P/2)-1
    for y=(-Q/2):(Q/2)-1
      Dk=((x+u0)^2+(y+v0)^2)^(0.5);
      H(x+(P/2)+1,y+(Q/2)+1)=H(x+(P/2)+1,y+(Q/2)+1) * 1/(1+(D0k/Dk)^8);
      Dk=((x-u0)^2+(y-v0)^2)^(0.5);
      H(x+(P/2)+1,y+(Q/2)+1)=H(x+(P/2)+1,y+(Q/2)+1) * 1/(1+(D0k/Dk)^8);
    end
end
out=H.*g_f;
out1=real(ifft2(ifftshift(out)));
out2=out1(1:m,1:n);
figure(4);
imshow(uint8(out2));