figure;
subplot(2,2,1)%չʾԭͼ
load('Test2.mat'); 
S = noise_my( 'salt & pepper', 448, 464, 0.1, 0.1);
I1 = f; 
c = find(S == 0);
I1(c) = 0; 
c = find(S==255);
I1(c) = 255; 
colormap(gray(256));subplot(2,2,1);image(I1);
axis image;axis off;colormap(gray(256));title('image with salt&peper');
%================================
I = f;
I2 = medfilt_my(I1); % ������ֵ�˲���
subplot(2,2,2);
image(I2);colormap(gray(256));axis image;axis off;title('Median filter');
%=========================================================================
I3 = medfilt_my(I1); % ������ֵ�˲���
subplot(2,2,3);
image(I3);axis image;axis off;colormap(gray(256));title('Twice median filter');
%==========================================================================
I4 = adpmedian(I1, 7);% ��������Ӧ��ֵ�˲���
subplot(2,2,4);
image(I4);colormap(gray(256));axis image;axis off;title('Adaptive median filter');
%==========================================================================