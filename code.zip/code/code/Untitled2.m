A=[1,2,0;0,3,3] %ͳ�ƾ���A�з�0Ԫ�صĸ���
sum(sum(A~=0))

dx = [-1 1; 0 0];
dy = [-1 0; 1 0];


im1 = imread('7_patch_use_interim_result.png');
r1 = im1(:,:,1);
im2 = imread('our.png');
r2 = im2(:,:,1);
im3 = imread('teacher.bmp');
r3 = im3(:,:,1);
figure(1)
g_x = conv2(r1, dx, 'same');
g_y = conv2(r1, dy, 'same');
g=g_x+g_y;
g_hist = imhist(g);        % ���ֱ��ͼ
subplot(1,3,1);bar(g_hist,'b');title('����');
Sharp_gradL0=sum(sum(g~=0))


g_x = conv2(r2, dx, 'same');
g_y = conv2(r2, dy, 'same');
g=g_x.^2+g_y.^2;
g_hist = imhist(g);  
subplot(1,3,2);bar(g_hist,'b');title('��ģ��');
Pan_gradL0=sum(sum(g~=0))

g_x = conv2(r3, dx, 'same');
g_y = conv2(r3, dy, 'same');
g=g_x.^2+g_y.^2;
g_hist = imhist(g); 
g_hist = imhist(g);        % ���ֱ��ͼ
subplot(1,3,3);bar(g_hist,'b');title('�� ģ��');
Xu_gradL0=sum(sum(g~=0))

am=im2bw(r1,0.29);
am=1-am;
figure(5)
imshow((1-am))
%-----------------------------------------------
% I = am;  
% figure(1)
% subplot(121);imshow(I); title('ԭͼ��');
% se = strel('disk',2);        
% I2 = imerode(I,se);
% BW=im2bw(I2,0.433);
% subplot(122);imshow(BW);title('��ʴͼ��');
% 
% figure(8)
% I = BW;  
% subplot(121);imshow(I); title('ԭͼ��');
% se = strel('disk',2);        
% I2 = imerode(I,se);
% %BW=im2bw(I2,0.333);
% subplot(122);imshow(I2);title('��ʴͼ��');

%-----------------------------------------------
x = [-1 -2 -1
    0 0 0;
    1 2 1];
y = [-1 0 1;
     -2 0 2
     -1 0 1]
z=[1 -1]
h=z'
b_x = conv2(am, z, 'same');
b_y = conv2(am, h, 'same');
g=b_x.^2+b_y.^2;
figure(3)
g=im2bw(g,0.85);
imshow(g);

 B=[0 1 0
    1 1 1
    0 1 0];
g=imdilate(am,B);%ͼ��A1���ṹԪ��B����
g=imdilate(am,B);



figure(4);
subplot(2,1,1)
imshow(10*uint8(g)+uint8(im(:,:,1)));
subplot(2,1,2)
imshow(am)

a=am(590:660,500:600)
b=im(590:660,500:600,1)

figure(8);
subplot(2,1,1)
imshow(1-a);
subplot(2,1,2)
imshow(b)
figure(9)
imshow(im)

% im = imread('7_patch_use_interim_result.png');
% am1 = im(:,:,1)
% figure(3)
% imshow(am1);


% im1 = imread('7_patch_use_interim_result.png');
% am1 = im(:,:,1)
% b_x = conv2(am1,x,'same');
% b_y = conv2(am1,y,'same');
% figure(4)
% g=uint8(b_x+b_y);
% imshow(g)
% BW1=im2bw(g,0.55);
% s  = regionprops(final, 'ConvexHull');
% s  = regionprops(final, 'ConvexHull');
% s  = regionprops(final, 'ConvexHull');
% s  = regionprops(final, 'ConvexHull');s  = regionprops(final, 'ConvexHull');
% % s  = regionprops(BW1, 'ConvexHull');
% s  = regionprops(BW1, 'ConvexHull');
% s  = regionprops(BW1, 'ConvexHull');
% s  = regionprops(BW1, 'ConvexHull');
% s  = regionprops(BW1, 'ConvexHull');
% s  = regionprops(BW1, 'ConvexHull');
% s  = regionprops(BW1, 'ConvexHull');s  = regionprops(BW, 'ConvexHull');
% s  = regionprops(BW1, 'ConvexHull');








